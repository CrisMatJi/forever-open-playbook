-- Forever PvP Tournament · checklist para The Forever Open
-- /tfo para abrir · /tfo export para sincronizar con la web · /tfo help

local ADDON, ns = ...
local DB

local GOLD, GREEN, RED, GREY, WHITE, PURPLE = "|cffffd100", "|cff1eff00", "|cffff4a3d", "|cff9d9d9d", "|cffffffff", "|cffb760ff"
local END = "|r"

------------------------------------------------------------
-- Datos
------------------------------------------------------------
local PROF_NAMES = {
  alchemy        = {"Alchemy", "Alquimia"},
  blacksmithing  = {"Blacksmithing", "Herrería"},
  enchanting     = {"Enchanting", "Encantamiento"},
  engineering    = {"Engineering", "Ingeniería"},
  leatherworking = {"Leatherworking", "Peletería"},
  tailoring      = {"Tailoring", "Sastrería"},
  skinning       = {"Skinning", "Desuello"},
  mining         = {"Mining", "Minería"},
  herbalism      = {"Herbalism", "Herboristería"},
  firstaid       = {"First Aid", "Primeros auxilios"},
  cooking        = {"Cooking", "Cocina"},
  fishing        = {"Fishing", "Pesca"},
}
local PROF_BY_NAME = {}
for key, names in pairs(PROF_NAMES) do
  for _, n in ipairs(names) do PROF_BY_NAME[string.lower(n)] = key end
end
local CRAFTS = {"alchemy", "blacksmithing", "enchanting", "engineering", "leatherworking", "tailoring"}

-- Prohibidos por el reglamento (IDs de Classic + nombres en inglés y español)
local BANNED_IDS = {
  [2091] = true,                                                        -- Magic Dust
  [6048] = true, [6049] = true, [6050] = true, [6051] = true, [6052] = true, -- Protection Potions
  [13456] = true, [13457] = true, [13458] = true, [13459] = true, [13460] = true, [13461] = true, -- Greater Protection Potions
}
local BANNED_PATTERNS = {"protection potion", "poción de protección", "magic dust", "polvo mágico"}

-- BiS de nivel 20 para Mejora PvP (nombres en inglés: solo se detectan con el cliente en inglés)
local BIS20 = {
  "Defender's Leather Hood", "Erudite's Amulet", "Serpent's Shoulders", "Grave Shroud",
  "Blackened Defias Armor", "Cultist's Armguards", "Brawler's Leather Gloves", "Deviate Scale Belt",
  "Duty Bound Leggings", "Brawler's Leather Boots", "Malignant Root", "First Mate Band",
  "Minor Recombobulator", "Lookie's Spyglass", "Smite's Mighty Hammer",
}

------------------------------------------------------------
-- Utilidades de lectura
------------------------------------------------------------
local function charKey()
  return (UnitName("player") or "?") .. "-" .. (GetRealmName() or "?")
end

local function main()
  return (DB and DB.main and DB.chars[DB.main]) or {}
end

local function prof(c, key)
  return (c and c.profs and c.profs[key]) or 0
end

local function findChar(fn)
  for key, c in pairs(DB.chars) do
    if key ~= DB.main and fn(c) then return c, key end
  end
end

local function anyChar(fn)
  for _, c in pairs(DB.chars) do if fn(c) then return true end end
  return false
end

-- IDs de línea de habilidad: no dependen del idioma del cliente
local SKILL_IDS = {
  [171] = "alchemy", [164] = "blacksmithing", [333] = "enchanting", [202] = "engineering",
  [165] = "leatherworking", [197] = "tailoring", [393] = "skinning", [186] = "mining",
  [182] = "herbalism", [129] = "firstaid", [185] = "cooking", [356] = "fishing",
}
-- Hechizos que se aprenden con cada profesión (último recurso: sabemos que la tienes, no su nivel)
local PROF_SPELLS = {
  skinning = {8613, 8617, 8618, 10768}, mining = {2575, 2576, 3564, 10248, 2580},
  herbalism = {2366, 2368, 3570, 11993, 2383}, leatherworking = {2108, 3104, 3811, 10662},
  engineering = {4036, 4037, 4038, 12656}, alchemy = {2259, 3101, 3464, 11611},
  blacksmithing = {2018, 3100, 3538, 9785}, enchanting = {7411, 7412, 7413, 13920},
  tailoring = {3908, 3909, 3910, 12180}, firstaid = {3273, 3274, 7924, 10846},
  cooking = {2550, 3102, 3413, 18260}, fishing = {7620, 7731, 7732, 18248},
}
local profSource = "ninguna"

local function knowsSpell(id)
  if IsPlayerSpell then local ok, r = pcall(IsPlayerSpell, id) if ok and r then return true end end
  if IsSpellKnown then local ok, r = pcall(IsSpellKnown, id) if ok and r then return true end end
  return false
end

local function normalize(s)
  s = string.lower(s or "")
  local map = {["á"]="a", ["é"]="e", ["í"]="i", ["ó"]="o", ["ú"]="u", ["Á"]="a", ["É"]="e", ["Í"]="i", ["Ó"]="o", ["Ú"]="u", ["ñ"]="n"}
  for k, v in pairs(map) do s = s:gsub(k, v) end
  return s
end
local PROF_BY_NORM = {}
for name, key in pairs(PROF_BY_NAME) do PROF_BY_NORM[normalize(name)] = key end

local function readProfessions()
  local out, sources = {}, {}
  -- 1) API moderna: GetProfessions + GetProfessionInfo (ID de habilidad)
  if GetProfessions and GetProfessionInfo then
    local list = {GetProfessions()}
    for i = 1, 6 do
      local idx = list[i]
      if idx then
        local name, _, rank, _, _, _, skillLine = GetProfessionInfo(idx)
        local key = (skillLine and SKILL_IDS[skillLine]) or PROF_BY_NORM[normalize(name)]
        if key then out[key] = rank or 1 sources.api = true end
      end
    end
  end
  -- 2) API de Classic: líneas de habilidad por nombre
  if GetNumSkillLines and GetSkillLineInfo then
    for i = GetNumSkillLines(), 1, -1 do
      local _, isHeader, isExpanded = GetSkillLineInfo(i)
      if isHeader and not isExpanded and ExpandSkillHeader then pcall(ExpandSkillHeader, i) end
    end
    for i = 1, GetNumSkillLines() do
      local name, isHeader, _, rank = GetSkillLineInfo(i)
      if name and not isHeader then
        local key = PROF_BY_NORM[normalize(name)]
        if key and (out[key] or 0) < (rank or 0) then out[key] = rank sources.skills = true end
      end
    end
  end
  -- 3) Último recurso: hechizos aprendidos
  for key, spells in pairs(PROF_SPELLS) do
    if not out[key] then
      for _, id in ipairs(spells) do
        if knowsSpell(id) then out[key] = 1 sources.spells = true break end
      end
    end
  end
  local s = {}
  for k in pairs(sources) do table.insert(s, k) end
  profSource = (#s > 0) and table.concat(s, "+") or "ninguna"
  return out
end

function ns.Debug()
  print(GOLD .. "TFO diagnóstico" .. END)
  print("GetProfessions: " .. tostring(GetProfessions ~= nil) .. " · GetSkillLineInfo: " .. tostring(GetSkillLineInfo ~= nil) .. " · IsPlayerSpell: " .. tostring(IsPlayerSpell ~= nil))
  local p = readProfessions()
  local parts = {}
  for k, v in pairs(p) do table.insert(parts, k .. "=" .. v) end
  print("Profesiones detectadas (" .. profSource .. "): " .. (#parts > 0 and table.concat(parts, ", ") or "ninguna"))
  if GetNumSkillLines and GetSkillLineInfo then
    local raw = {}
    for i = 1, math.min(GetNumSkillLines(), 40) do
      local name, isHeader, _, rank = GetSkillLineInfo(i)
      if name then table.insert(raw, (isHeader and "[" .. name .. "]" or (name .. " " .. (rank or "?")))) end
    end
    print("Líneas de habilidad: " .. table.concat(raw, " · "))
  end
  local tt, nSpells = readTotems()
  local tl = {}
  for el in pairs(tt) do tl[#tl + 1] = el end
  print("Tótems detectados: " .. (#tl > 0 and table.concat(tl, ", ") or "ninguno") .. " · hechizos leídos del libro: " .. tostring(nSpells))
  local tools = readTools()
  print("Herramientas: pico " .. tostring(tools.pick == true) .. " · cuchillo " .. tostring(tools.knife == true))
  local m = main()
  print("Main: " .. tostring(DB.main) .. " · clase " .. tostring(m.class) .. " · raza " .. tostring(m.race) .. " · facción " .. tostring(m.faction))
end

-- Tótems conocidos: las misiones de tótem se dan por hechas si conoces un tótem de ese elemento.
-- Se mira por ID (Classic) y por nombre en el libro de hechizos (inglés y español).
local TOTEM_IDS = {
  earth = {8071, 2484, 5730, 8075, 8143, 8154, 8155, 10406, 6390, 6391, 8160, 8161},
  fire  = {3599, 1535, 8181, 8190, 8227, 6363, 6364, 8498},
  water = {5394, 5675, 8166, 8170, 8184, 6375, 6377},
  air   = {8177, 8512, 8835, 10595, 15107, 6495},
}
local TOTEM_WORDS = {
  earth = {"earthbind", "stoneskin", "stoneclaw", "strength of earth", "tremor", "nexo terrestre", "piel de piedra", "garra de piedra", "fuerza de la tierra", "temblor"},
  fire  = {"searing", "fire nova", "magma", "flametongue", "frost resistance", "abrasador", "nova de fuego", "lengua de fuego", "resistencia a la escarcha"},
  water = {"healing stream", "mana spring", "poison cleansing", "disease cleansing", "fire resistance", "corriente de sanacion", "fuente de mana", "limpieza de veneno", "limpieza de enfermedad", "resistencia al fuego"},
  air   = {"grounding", "windfury", "grace of air", "nature resistance", "windwall", "tranquil air", "derribo", "viento furioso", "gracia del aire", "resistencia a la naturaleza", "muro de viento", "aire sosegado"},
}
local function spellbookNames()
  local names = {}
  local book = BOOKTYPE_SPELL or "spell"
  local getName = GetSpellBookItemName or GetSpellName
  if GetNumSpellTabs and GetSpellTabInfo and getName then
    for tab = 1, GetNumSpellTabs() do
      local _, _, offset, num = GetSpellTabInfo(tab)
      for i = (offset or 0) + 1, (offset or 0) + (num or 0) do
        local ok, n = pcall(getName, i, book)
        if ok and n then names[#names + 1] = normalize(n) end
      end
    end
  elseif C_SpellBook and C_SpellBook.GetNumSpellBookSkillLines then
    for tab = 1, C_SpellBook.GetNumSpellBookSkillLines() do
      local info = C_SpellBook.GetSpellBookSkillLineInfo(tab)
      if info then
        for i = info.itemIndexOffset + 1, info.itemIndexOffset + info.numSpellBookItems do
          local ok, n = pcall(C_SpellBook.GetSpellBookItemName, i, Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player or 0)
          if ok and n then names[#names + 1] = normalize(n) end
        end
      end
    end
  end
  return names
end
local function readTotems()
  local out = {}
  for el, ids in pairs(TOTEM_IDS) do
    for _, id in ipairs(ids) do if knowsSpell(id) then out[el] = true break end end
  end
  local names = spellbookNames()
  for _, n in ipairs(names) do
    if n:find("totem", 1, true) then
      for el, words in pairs(TOTEM_WORDS) do
        if not out[el] then
          for _, w in ipairs(words) do if n:find(w, 1, true) then out[el] = true break end end
        end
      end
    end
  end
  return out, #names
end
ns.ReadTotems = readTotems

-- Herramientas por ID de objeto (no depende del idioma del cliente)
local TOOL_IDS = {pick = {2901, 756, 778, 1819, 1959}, knife = {7005, 12709}, hammer = {5956}, spanner = {6219}}
local function itemCount(id)
  if C_Item and C_Item.GetItemCount then local ok, n = pcall(C_Item.GetItemCount, id) if ok and n then return n end end
  if GetItemCount then local ok, n = pcall(GetItemCount, id) if ok and n then return n end end
  return 0
end
local function readTools()
  local out = {}
  for tool, ids in pairs(TOOL_IDS) do
    for _, id in ipairs(ids) do if itemCount(id) > 0 then out[tool] = true break end end
  end
  -- también si lo llevas equipado (algunas herramientas son arma)
  if GetInventoryItemID then
    for slot = 16, 18 do
      local id = GetInventoryItemID("player", slot)
      for tool, ids in pairs(TOOL_IDS) do for _, x in ipairs(ids) do if x == id then out[tool] = true end end end
    end
  end
  return out
end

local function readTalents()
  local ranks, spent = {}, 0
  if not GetNumTalentTabs then return ranks, 0 end
  for tab = 1, GetNumTalentTabs() do
    for i = 1, (GetNumTalents(tab) or 0) do
      local _, _, tier, column, rank = GetTalentInfo(tab, i)
      if tier and column and rank and rank > 0 then
        ranks[tab .. ":" .. tier .. ":" .. column] = rank
        spent = spent + rank
      end
    end
  end
  return ranks, spent
end

-- Nombre de un objeto por ID: el cliente de Forever movió GetItemInfo a C_Item
local function itemName(id)
  if C_Item and C_Item.GetItemNameByID then
    local ok, n = pcall(C_Item.GetItemNameByID, id)
    if ok and n then return n end
  end
  if C_Item and C_Item.GetItemInfo then
    local ok, n = pcall(C_Item.GetItemInfo, id)
    if ok and type(n) == "string" then return n end
  end
  if GetItemInfo then
    local ok, n = pcall(GetItemInfo, id)
    if ok and n then return n end
  end
  return nil
end

local function containerAPI()
  local C = C_Container
  local numSlots = (C and C.GetContainerNumSlots) or GetContainerNumSlots
  local itemID = (C and C.GetContainerItemID) or GetContainerItemID
  return numSlots, itemID
end

local function scanBags()
  local banned = {}
  local numSlots, itemID = containerAPI()
  if not numSlots or not itemID then return banned end
  for bag = 0, (NUM_BAG_SLOTS or 4) do
    for slot = 1, (numSlots(bag) or 0) do
      local id = itemID(bag, slot)
      if id then
        local name = itemName(id)
        local hit = BANNED_IDS[id]
        if not hit and name then
          local low = string.lower(name)
          for _, p in ipairs(BANNED_PATTERNS) do
            if string.find(low, p, 1, true) then hit = true break end
          end
        end
        if hit then table.insert(banned, name or ("objeto " .. id)) end
      end
    end
  end
  return banned
end

local function readEquipment()
  local names, minDur = {}, 1
  for slot = 1, 19 do
    local link = GetInventoryItemLink and GetInventoryItemLink("player", slot)
    if link then
      local n = link:match("%[(.-)%]")
      if n then names[n] = true end
      local id = tonumber(link:match("item:(%d+)"))
      if id then names["id:" .. id] = true end
    end
    local cur, max
    if GetInventoryItemDurability then cur, max = GetInventoryItemDurability(slot) end
    if cur and max and max > 0 then minDur = math.min(minDur, cur / max) end
  end
  return names, minDur
end

------------------------------------------------------------
-- Instantánea del personaje actual
------------------------------------------------------------
local function snapshot()
  if not DB then return end
  local key = charKey()
  local c = DB.chars[key] or {}
  local _, classToken = UnitClass("player")
  local _, raceToken = UnitRace("player")
  c.name = UnitName("player")
  c.realm = GetRealmName()
  c.class = classToken
  c.race = raceToken
  c.faction = UnitFactionGroup("player")
  c.level = UnitLevel("player")
  c.money = GetMoney()
  c.guild = GetGuildInfo("player")
  local function safe(fn, label, ...)
    local res = {pcall(fn, ...)}
    if res[1] then return select(2, unpack(res)) end
    if not DB.warned then DB.warned = {} end
    if not DB.warned[label] then
      DB.warned[label] = true
      print(GOLD .. "TFO:" .. END .. " no he podido leer " .. label .. " en este cliente: " .. tostring(res[2]))
    end
  end
  c.profs = safe(readProfessions, "las profesiones") or c.profs or {}
  local t, sp = safe(readTalents, "los talentos")
  if t then c.talents, c.spent = t, sp end
  c.unspent = 0
  if UnitCharacterPoints then
    local ok, v = pcall(UnitCharacterPoints, "player")
    if ok and type(v) == "number" then c.unspent = v end
  end
  local eq, dur = safe(readEquipment, "el equipo")
  if eq then c.equip, c.durability = eq, dur end
  c.banned = safe(scanBags, "las bolsas") or {}
  c.tools = safe(readTools, "las herramientas") or c.tools or {}
  if classToken == "SHAMAN" then c.totems = safe(readTotems, "los tótems") or c.totems or {} end
  c.updated = time()
  DB.chars[key] = c
  if not DB.main and classToken == "SHAMAN" and c.faction == "Horde" then DB.main = key end
end

------------------------------------------------------------
-- Cálculos
------------------------------------------------------------
local function legacyEstimate()
  local classes, classCount = {}, 0
  for _, c in pairs(DB.chars) do
    if c.class and (c.level or 0) >= 25 and not classes[c.class] then
      classes[c.class] = true
      classCount = classCount + 1
    end
  end
  local profPts = 0
  for _, k in ipairs(CRAFTS) do
    local best = 0
    for _, c in pairs(DB.chars) do best = math.max(best, prof(c, k)) end
    if best >= 150 then profPts = profPts + 1 end
    if best >= 225 then profPts = profPts + 1 end
  end
  return classCount + profPts + (DB.legacyExtra or 0), classCount, profPts
end

local function buildStatus(c)
  local target = c and c.class and ns.BUILDS[c.class]
  if not target then return 0, 0, {} end
  local ok, total, missing = 0, 0, {}
  local want = {}
  for _, t in ipairs(target) do
    local k = t[1] .. ":" .. t[2] .. ":" .. t[3]
    want[k] = t[4]
    total = total + t[4]
    local have = (c.talents and c.talents[k]) or 0
    ok = ok + math.min(have, t[4])
    if have < t[4] then table.insert(missing, t[5] .. " " .. have .. "/" .. t[4]) end
  end
  local wrong = 0
  for k, r in pairs(c.talents or {}) do
    if not want[k] then wrong = wrong + r
    elseif r > want[k] then wrong = wrong + (r - want[k]) end
  end
  return ok, total, missing, wrong
end

local function bisCount(c)
  local n = 0
  for _, name in ipairs(BIS20) do if c.equip and c.equip[name] then n = n + 1 end end
  return n
end

local function isHunter(c) return c.class == "HUNTER" end

------------------------------------------------------------
-- Checklist (las claves coinciden con la pestaña "Mi guía" de la web)
------------------------------------------------------------
local SECTIONS = {
  {id = "ins", title = "1 · Inscripción (hasta el 4 oct)", items = {
    {"Chamán Orco nuevo, Horda, ruleset PvP", function() local m = main() return m.class == "SHAMAN" and m.race == "Orc" and m.faction == "Horde" end},
    {"Apellido Foreverpvp"},
    {"Inscrito en rio.gg/foreveropen"},
    {"En la hermandad <The Forever Open>", function() return main().guild == "The Forever Open" end},
    {"En el Discord Forever PvP"},
    {"Inscripción comprobada antes del 4 oct, 20:00"},
  }},
  {id = "str", title = "2 · Streaming obligatorio", items = {
    {"Canal en Twitch, YouTube o Kick"},
    {"OBS configurado y emisión de prueba"},
    {"Guardado de emisiones (VOD) activado"},
    {"Sabes enseñar bolsas, talentos y personaje en directo"},
  }},
  {id = "l1", title = "3 · Nivel 1-10: Durotar", items = {
    {"Nivel 10", function() return (main().level or 0) >= 10 end},
    {"Desuello y Minería aprendidos", function() local m = main() return (prof(m, "skinning") > 0 and prof(m, "mining") > 0) or (prof(m, "leatherworking") > 0 and prof(m, "engineering") > 0) end},
    {"Primeros auxilios y Cocina aprendidos", function() local m = main() return prof(m, "firstaid") > 0 and prof(m, "cooking") > 0 end},
    {"Despellejas y minas todo; al banco"},
    {"Misiones de tótem de Tierra y Fuego", function() local tt = main().totems return tt and tt.earth and tt.fire end},
    {"Primer talento: Thundering Strikes", function() local t = main().talents return t and (t["2:1:2"] or 0) >= 1 end},
  }},
  {id = "l2", title = "4 · Nivel 10-20: Los Baldíos", items = {
    {"Pawani localizado (fuera de El Cruce)"},
    {"Juntando Merchant's Favor con Waylaid Supplies"},
    {"Equipo de misiones y mazmorras para subir"},
    {"Mazmorras del rango hechas una vez"},
    {"Libros de la biblioteca en marcha"},
    {"Misión del Tótem de Agua", function() local tt = main().totems return tt and tt.water end},
    {"Misiones guardadas para cuando suba el cap"},
    {"Desuello y Minería a 100 o más", function() local m = main() return (prof(m, "skinning") >= 100 and prof(m, "mining") >= 100) or prof(m, "leatherworking") > 0 end},
  }},
  {id = "alt1", title = "5 · Empieza el Cazador", items = {
    {"Cazador creado", function() return findChar(isHunter) ~= nil end},
    {"Cazador con Sastrería y Encantamiento", function() local h = findChar(isHunter) return h and prof(h, "tailoring") > 0 and prof(h, "enchanting") > 0 end},
    {"Cazador nivel 10", function() local h = findChar(isHunter) return h and (h.level or 0) >= 10 end},
    {"Cazador nivel 20", function() local h = findChar(isHunter) return h and (h.level or 0) >= 20 end},
  }},
  {id = "l3", title = "6 · Chamán del 20 al 25", items = {
    {"Misiones guardadas entregadas"},
    {"Zonas de 20-25"},
    {"Brazales, piernas y capa de misiones"},
    {"Excavation Site hecha"},
    {"Nivel 25: Legacy abierto", function() return (main().level or 0) >= 25 end},
  }},
  {id = "l4", title = "7 · Nivel 28-30: Peletería e Ingeniería", items = {
    {"Peletería e Ingeniería aprendidas (recolección olvidada)", function() local m = main() return prof(m, "leatherworking") > 0 and prof(m, "engineering") > 0 end},
    {"Peletería 225", function() return prof(main(), "leatherworking") >= 225 end},
    {"Ingeniería 225", function() return prof(main(), "engineering") >= 225 end},
    {"Cuero y mineral sobrantes vendidos"},
    {"Ingeniería 140 y Minor Recombobulator", function() local m = main() return prof(m, "engineering") >= 140 and m.equip and (m.equip["Minor Recombobulator"] or m.equip["id:4381"]) and true or nil end},
    {"Nivel 30 y misión del Tótem de Aire", function() local m = main() return (m.level or 0) >= 30 and m.totems and m.totems.air end},
    {"City of Dalaran hecha"},
  }},
  {id = "leg", title = "8 · Cierra los 10 puntos de Legacy", items = {
    {"Cazador nivel 25", function() local h = findChar(isHunter) return h and (h.level or 0) >= 25 end},
    {"Sastrería y Encantamiento a 150 en la cuenta", function() return anyChar(function(c) return prof(c, "tailoring") >= 150 end) and anyChar(function(c) return prof(c, "enchanting") >= 150 end) end},
    {"Alquimia y Herrería a 150 en la cuenta", function() return anyChar(function(c) return prof(c, "alchemy") >= 150 end) and anyChar(function(c) return prof(c, "blacksmithing") >= 150 end) end},
    {"10 puntos de Legacy (estimación)", function() return (legacyEstimate()) >= 10 end},
    {"Well Rested 5/5 y Talented 5/5 gastados"},
    {"26 puntos de talento con la build Mejora", function() local m = main() local ok, total = buildStatus(m) return total > 0 and ok >= total end},
  }},
  {id = "gear", title = "9 · Equipo y bolsa", items = {
    {"Piezas BiS de nivel 30 fabricadas (patrones con Merchant's Favor)"},
    {"Pociones, vendas, comida y bombas en la bolsa"},
    {"Piedra de peso para el arma"},
    {"Objetos de tótem en la bolsa"},
    {"Nada prohibido en las bolsas", function() local m = main() return m.banned ~= nil and #m.banned == 0 end},
    {"Equipo reparado (durabilidad 90% o más)", function() return (main().durability or 0) >= 0.9 end},
  }},
  {id = "fin", title = "10 · Semana del torneo", items = {
    {"Build enviada el 16 oct"},
    {"Duelos de práctica contra Brujo, Sacerdote, Pícaro y Mago"},
    {"Nivel 30 y 15 g para la entrada", function() local m = main() return (m.level or 0) >= 30 and (m.money or 0) >= 150000 end},
    {"Buffs de otros jugadores (2 min o más)"},
    {"Stream encendido"},
    {"Reglas de salida y de huida repasadas"},
  }},
}

------------------------------------------------------------
-- Ruta de speedrun por nivel (Route.lua): depende del personaje conectado
------------------------------------------------------------
local function current()
  return (DB and DB.chars[charKey()]) or {}
end

local function roleOf(key, c)
  if key == DB.main or (c.class == "SHAMAN" and not DB.main) then return "main" end
  if c.class == "HUNTER" then return "hunter" end
  return "filler"
end

local GATHER = {skinning = true, mining = true}

-- Convierte un paso de datos en {texto, comprobación, tip, prog}
local function compileStep(role, it)
  local check
  if it.p then
    local k, target = it.p[1], it.p[2]
    check = function()
      local c = current()
      if prof(c, k) >= target then return true end
      -- el main olvida la recolección a nivel 28: lo anterior cuenta como hecho
      if role == "main" and GATHER[k] and (prof(c, "leatherworking") > 0 or prof(c, "engineering") > 0) then return true end
    end
  elseif it.learn then
    check = function()
      local c = current()
      for _, k in ipairs(it.learn) do if prof(c, k) <= 0 then
        if not (role == "main" and GATHER[k] and prof(c, "leatherworking") > 0) then return false end
      end end
      return true
    end
  elseif it.lvl then
    check = function() return (current().level or 0) >= it.lvl end
  elseif it.equip then
    check = function() local e = current().equip return e and (e[it.equip] or (it.equipId and e["id:" .. it.equipId])) and true or nil end
  elseif it.tools then
    check = function()
      local c = current()
      if role == "main" and prof(c, "leatherworking") > 0 then return true end
      for _, k in ipairs(it.tools) do if not (c.tools and c.tools[k]) then return false end end
      return true
    end
  elseif it.totem then
    check = function() local tt = current().totems return tt and tt[it.totem] or nil end
  elseif it.build then
    check = function() local ok, total = buildStatus(current()) return total > 0 and ok >= total end
  end
  return {it[1], check, tip = it.tip, prog = it.p}
end

local ROUTE, ROLE = {}, "main"
local ALL = SECTIONS

local function buildRoute()
  local c = current()
  ROLE = roleOf(charKey(), c)
  local src = ns.ROUTES and ns.ROUTES[ROLE]
  ROUTE = {}
  if src then
    for _, s in ipairs(src.sections) do
      local sec = {id = s.id, from = s.from, to = s.to, title = s.title, route = true, items = {}}
      for _, it in ipairs(s.items) do table.insert(sec.items, compileStep(ROLE, it)) end
      table.insert(ROUTE, sec)
    end
  end
  ALL = {}
  for _, s in ipairs(ROUTE) do table.insert(ALL, s) end
  for _, s in ipairs(SECTIONS) do table.insert(ALL, s) end
end

local function itemKey(sec, j) return sec.id .. "-" .. (j - 1) end

local function isDone(sec, j)
  local item = sec.items[j]
  local key = itemKey(sec, j)
  if item[2] then
    local ok, res = pcall(item[2])
    if ok and res then
      if sec.route then DB.routeSeen[key] = true end
      return true, true
    end
    -- en la ruta, lo que ya se cumplió una vez no se desmarca (p. ej. al olvidar Desuello)
    if sec.route and DB.routeSeen[key] then return true, true end
  end
  return DB.manual[key] and true or false, false
end

-- Texto del paso con progreso "(87/100)" si es de profesión
local function itemLabel(sec, j, done)
  local item = sec.items[j]
  local text = item[1]
  if item.prog and not done then
    text = text .. GREY .. string.format("  %d/%d", prof(current(), item.prog[1]), item.prog[2]) .. END
  end
  return text
end

------------------------------------------------------------
-- Interfaz: estilo de marcos de WoW (oscuro, borde dorado)
------------------------------------------------------------
local frame, scrollChild, rows = nil, nil, {}
local mini, miniLines = nil, {}
local MINI_VIEW = 260  -- alto de la lista en modo automático (sin tamaño guardado)
local MINI_W = 300
local MIN_W, MIN_H, MAX_W, MAX_H = 220, 120, 700, 1000
local WHITE8 = "Interface\\Buttons\\WHITE8x8"
local ICON_DONE = "Interface\\RaidFrame\\ReadyCheck-Ready"
local ICON_AUTO = "Interface\\RaidFrame\\ReadyCheck-Waiting"
local ICON_BOX  = "Interface\\Buttons\\UI-CheckBox-Up"
local BAR_TEX   = "Interface\\TargetingFrame\\UI-StatusBar"

local function skin(f, alpha)
  if not f.SetBackdrop then return end
  f:SetBackdrop({bgFile = WHITE8, edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = false, edgeSize = 14, insets = {left = 3, right = 3, top = 3, bottom = 3}})
  f:SetBackdropColor(0.06, 0.05, 0.04, alpha or 0.94)
  f:SetBackdropBorderColor(0.78, 0.62, 0.28, 1)
end

local function newFrame(name, parent)
  return CreateFrame("Frame", name, parent or UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
end

local function titleBar(f, text, height)
  local bar = f:CreateTexture(nil, "ARTWORK")
  bar:SetTexture(WHITE8)
  bar:SetVertexColor(0.18, 0.13, 0.07, 1)
  bar:SetPoint("TOPLEFT", 4, -4)
  bar:SetPoint("TOPRIGHT", -4, -4)
  bar:SetHeight(height or 24)
  local line = f:CreateTexture(nil, "ARTWORK")
  line:SetTexture(WHITE8)
  line:SetVertexColor(0.78, 0.62, 0.28, 0.8)
  line:SetPoint("TOPLEFT", bar, "BOTTOMLEFT")
  line:SetPoint("TOPRIGHT", bar, "BOTTOMRIGHT")
  line:SetHeight(1)
  local fs = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  fs:SetPoint("LEFT", bar, "LEFT", 8, 0)
  fs:SetText(text)
  return fs, bar
end

local function smallButton(parent, label, tip, onClick)
  local b = CreateFrame("Button", nil, parent, BackdropTemplateMixin and "BackdropTemplate" or nil)
  b:SetSize(20, 18)
  if b.SetBackdrop then
    b:SetBackdrop({bgFile = WHITE8, edgeFile = WHITE8, edgeSize = 1})
    b:SetBackdropColor(0.25, 0.08, 0.05, 1)
    b:SetBackdropBorderColor(0.78, 0.62, 0.28, 0.9)
  end
  local fs = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  fs:SetPoint("CENTER", 0, 1)
  fs:SetText(label)
  b:SetScript("OnClick", onClick)
  b:SetScript("OnEnter", function(self)
    if self.SetBackdropColor then self:SetBackdropColor(0.45, 0.12, 0.07, 1) end
    GameTooltip:SetOwner(self, "ANCHOR_TOP") GameTooltip:AddLine(tip) GameTooltip:Show()
  end)
  b:SetScript("OnLeave", function(self)
    if self.SetBackdropColor then self:SetBackdropColor(0.25, 0.08, 0.05, 1) end
    GameTooltip:Hide()
  end)
  return b
end

local function wideButton(parent, label, width, onClick)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetSize(width, 22)
  b:SetText(label)
  b:SetScript("OnClick", onClick)
  return b
end

local function progressBar(parent, width)
  local holder = newFrame(nil, parent)
  holder:SetSize(width, 16)
  if holder.SetBackdrop then
    holder:SetBackdrop({bgFile = WHITE8, edgeFile = WHITE8, edgeSize = 1})
    holder:SetBackdropColor(0, 0, 0, 0.7)
    holder:SetBackdropBorderColor(0.45, 0.36, 0.18, 1)
  end
  local bar = CreateFrame("StatusBar", nil, holder)
  bar:SetPoint("TOPLEFT", 1, -1)
  bar:SetPoint("BOTTOMRIGHT", -1, 1)
  bar:SetStatusBarTexture(BAR_TEX)
  bar:SetStatusBarColor(0.12, 0.75, 0.1)
  bar:SetMinMaxValues(0, 1)
  bar:SetValue(0)
  local fs = bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  fs:SetPoint("CENTER", 0, 0)
  holder.bar, holder.text = bar, fs
  return holder
end

local function summaryText()
  local m = main()
  if not m.name then
    return GOLD .. "Sin main." .. END .. " Entra con tu Chamán Orco o usa " .. WHITE .. "/tfo main" .. END .. " con él."
  end
  local lines = {}
  table.insert(lines, string.format("%s%s%s  ·  nivel %s%d%s  ·  %s%d%s oro", WHITE, m.name, END, WHITE, m.level or 0, END, WHITE, floor((m.money or 0) / 10000), END))
  table.insert(lines, string.format("Desuello %s%d%s · Minería %s%d%s · Peletería %s%d%s · Ingeniería %s%d%s",
    WHITE, prof(m, "skinning"), END, WHITE, prof(m, "mining"), END, WHITE, prof(m, "leatherworking"), END, WHITE, prof(m, "engineering"), END))
  table.insert(lines, string.format("Primeros auxilios %s%d%s · Cocina %s%d%s", WHITE, prof(m, "firstaid"), END, WHITE, prof(m, "cooking"), END))
  local lg, cls, pp = legacyEstimate()
  table.insert(lines, string.format("%sLegacy %d/10%s  (%d por clases a 25, %d por profesiones)", PURPLE, lg, END, cls, pp))
  local ok, total, _, wrong = buildStatus(m)
  if total > 0 then
    local t = string.format("Talentos de la build %s%d/%d%s · sin gastar %d", WHITE, ok, total, END, m.unspent or 0)
    if wrong and wrong > 0 then t = t .. RED .. " · " .. wrong .. " fuera de la build" .. END end
    table.insert(lines, t)
  end
  if m.banned and #m.banned > 0 then
    table.insert(lines, RED .. "PROHIBIDO en bolsas: " .. table.concat(m.banned, ", ") .. END)
  else
    table.insert(lines, GREEN .. "Bolsas limpias" .. END .. string.format(" · durabilidad mínima %d%%", floor((m.durability or 1) * 100)))
  end
  return table.concat(lines, "\n")
end

local refresh
-- Estado de toda la lista y avisos de lo recién completado
local function evaluate()
  local done, total, pending, secStats = 0, 0, {}, {}
  DB.autoSeen = DB.autoSeen or {}
  for _, sec in ipairs(ALL) do
    local sd = 0
    for j = 1, #sec.items do
      total = total + 1
      local d, auto = isDone(sec, j)
      local key = itemKey(sec, j)
      if d then
        done = done + 1
        sd = sd + 1
        if auto and not DB.autoSeen[key] then
          DB.autoSeen[key] = true
          if DB.announced then
            print(GOLD .. "TFO:" .. END .. " " .. GREEN .. "completado" .. END .. " · " .. sec.items[j][1])
            if UIErrorsFrame then UIErrorsFrame:AddMessage("Forever PvP: " .. sec.items[j][1], 1, 0.82, 0) end
            if PlaySound and SOUNDKIT and SOUNDKIT.IG_QUEST_LIST_COMPLETE then pcall(PlaySound, SOUNDKIT.IG_QUEST_LIST_COMPLETE) end
          end
        end
      else
        table.insert(pending, {sec = sec, j = j, key = key, auto = sec.items[j][2] ~= nil})
      end
    end
    secStats[sec.id] = sd
  end
  DB.announced = true
  return done, total, pending, secStats
end

local function rowIcon(d, auto, hasAuto)
  if d then return ICON_DONE end
  if hasAuto then return ICON_AUTO end
  return ICON_BOX
end

local function rowTooltip(self)
  local sec, item = self.sec, self.sec.items[self.j]
  GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
  GameTooltip:AddLine(item[1], 1, 1, 1, true)
  if sec.from then GameTooltip:AddLine(sec.title, 1, 0.82, 0, true) end
  if item.prog then
    GameTooltip:AddLine(string.format("Llevas %d de %d", prof(current(), item.prog[1]), item.prog[2]), 0.8, 0.8, 0.8, true)
  end
  if item.tip then GameTooltip:AddLine(item.tip, 0.75, 0.75, 0.75, true) end
  if item[2] then
    GameTooltip:AddLine("Automático: se marca solo cuando el addon lo detecta.", 0.1, 1, 0.1, true)
    GameTooltip:AddLine("Si no lo detecta, clic para marcarlo a mano.", 0.7, 0.7, 0.7, true)
  else
    GameTooltip:AddLine("Manual: clic para marcar o desmarcar.", 1, 0.82, 0, true)
  end
  GameTooltip:Show()
end

local function toggleManual(key)
  DB.manual[key] = (not DB.manual[key]) and true or nil
end

local function refreshFull(done, total, secStats)
  if not frame or not frame:IsShown() then return end
  frame.summary:SetText(summaryText())
  frame.progress.bar:SetValue(total > 0 and done / total or 0)
  frame.progress.text:SetText(string.format("%d / %d pasos", done, total))
  local y = -4
  for _, r in ipairs(rows) do
    if r.kind == "section" then
      local n = #r.sec.items
      local sd = secStats[r.sec.id] or 0
      local prefix = r.sec.route and (PURPLE .. "Ruta · " .. END) or ""
      r.fs:SetText(prefix .. (sd == n and GREEN or GOLD) .. r.sec.title .. END)
      r.count:SetText((sd == n and GREEN or GREY) .. sd .. "/" .. n .. END)
      r.frame:ClearAllPoints()
      r.frame:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, y)
      y = y - 26
    else
      local d, auto = isDone(r.sec, r.j)
      local hasAuto = r.sec.items[r.j][2] ~= nil
      r.icon:SetTexture(rowIcon(d, auto, hasAuto))
      local label = itemLabel(r.sec, r.j, d)
      if hasAuto and not d then label = label .. GREY .. "  · auto" .. END end
      r.fs:SetText(d and (GREY .. r.sec.items[r.j][1] .. END) or label)
      local h = math.max(20, r.fs:GetStringHeight() + 8)
      r:SetHeight(h)
      r:ClearAllPoints()
      r:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 4, y)
      y = y - h
    end
  end
  scrollChild:SetHeight(-y + 10)
end

-- Líneas del tracker: se crean según hagan falta
local function miniLine(i)
  if miniLines[i] then return miniLines[i] end
  local line = CreateFrame("Button", nil, mini.child)
  line.icon = line:CreateTexture(nil, "ARTWORK")
  line.icon:SetSize(12, 12)
  line.icon:SetPoint("TOPLEFT", 2, -2)
  line.fs = line:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  line.fs:SetJustifyH("LEFT")
  local hl = line:CreateTexture(nil, "HIGHLIGHT")
  hl:SetTexture(WHITE8)
  hl:SetVertexColor(1, 0.82, 0, 0.08)
  hl:SetAllPoints()
  line:SetScript("OnClick", function(self)
    if self.head == "checklist" then DB.miniChecklist = not DB.miniChecklist refresh()
    elseif self.key then toggleManual(self.key) refresh() end
  end)
  line:SetScript("OnEnter", function(self)
    if self.sec then rowTooltip(self)
    elseif self.head == "checklist" then
      GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
      GameTooltip:AddLine("Inscripción, stream, Legacy, equipo y semana del torneo.", 1, 1, 1, true)
      GameTooltip:AddLine("Clic para mostrar u ocultar.", 0.7, 0.7, 0.7)
      GameTooltip:Show()
    end
  end)
  line:SetScript("OnLeave", function() GameTooltip:Hide() end)
  miniLines[i] = line
  return line
end

-- Ordena lo pendiente según el nivel del personaje conectado
local function miniEntries(pending)
  local lvl = current().level or 1
  local late, now, nextList, rest = {}, {}, {}, {}
  local nextFrom, profShown = nil, {}
  -- de cada profesión solo se enseña el siguiente objetivo; el resto aparece al alcanzarlo
  local function firstOfProf(p)
    local pr = p.sec.items[p.j].prog
    if not pr then return true end
    if profShown[pr[1]] then return false end
    profShown[pr[1]] = true
    return true
  end
  for _, p in ipairs(pending) do
    local s = p.sec
    if s.route then
      if s.to < lvl then if firstOfProf(p) then table.insert(late, p) end
      elseif s.from <= lvl then if firstOfProf(p) then table.insert(now, p) end
      elseif not nextFrom or s.from == nextFrom then nextFrom = s.from table.insert(nextList, p) end
    else
      table.insert(rest, p)
    end
  end
  local out = {}
  local function head(text, tag) table.insert(out, {head = tag or true, text = text}) end
  if #late > 0 then
    head(RED .. "Atrasado (de niveles anteriores)" .. END)
    for _, p in ipairs(late) do table.insert(out, p) end
  end
  local lastSec
  for _, p in ipairs(now) do
    if p.sec ~= lastSec then head(GOLD .. "Ahora · " .. END .. WHITE .. p.sec.title .. END) lastSec = p.sec end
    table.insert(out, p)
  end
  lastSec = nil
  for _, p in ipairs(nextList) do
    if p.sec ~= lastSec then head(GREY .. "Siguiente · " .. p.sec.title .. END) lastSec = p.sec end
    table.insert(out, {sec = p.sec, j = p.j, key = p.key, auto = p.auto, dim = true})
  end
  if #rest > 0 then
    head(GOLD .. (DB.miniChecklist and "[-] " or "[+] ") .. "Checklist general (" .. #rest .. ")" .. END, "checklist")
    if DB.miniChecklist then for _, p in ipairs(rest) do table.insert(out, p) end end
  end
  return out, #late + #now
end

local function refreshMini(done, total, pending)
  if not mini or not mini:IsShown() then return end
  local c, m = current(), main()
  mini.progress.bar:SetValue(total > 0 and done / total or 0)
  mini.progress.text:SetText(string.format("%d / %d", done, total))
  local lg = legacyEstimate()
  local ok, tot = buildStatus(m)
  local warn = (m.banned and #m.banned > 0) and (RED .. "  ¡Objeto prohibido en bolsa!" .. END) or ""
  local who = (ROLE == "main") and "" or (GREY .. (ns.ROUTES and ns.ROUTES[ROLE] and ns.ROUTES[ROLE].label or "") .. " · " .. END)
  mini.stats:SetText(string.format("%sNv %s%d%s · %sLegacy %d/10%s · Talentos %s%d/%d%s%s", who, WHITE, c.level or 0, END, PURPLE, lg, END, WHITE, ok, tot, END, warn))

  local w = mini:GetWidth()
  local cw = math.max(100, w - 36)
  mini.child:SetWidth(cw)
  local top = 50 + math.max(12, mini.stats:GetStringHeight()) + 6
  mini.scroll:ClearAllPoints()
  mini.scroll:SetPoint("TOPLEFT", 8, -top)
  mini.scroll:SetPoint("BOTTOMRIGHT", -26, 12)

  local entries = miniEntries(pending)
  local y = 0
  for i, e in ipairs(entries) do
    local line = miniLine(i)
    line:SetWidth(cw)
    line.fs:ClearAllPoints()
    if e.head then
      line.head, line.key, line.sec, line.j = e.head, nil, nil, nil
      line.icon:Hide()
      line.fs:SetPoint("TOPLEFT", 0, -4)
      line.fs:SetWidth(cw)
      line.fs:SetText(e.text)
    else
      line.head, line.key, line.sec, line.j = nil, e.key, e.sec, e.j
      line.icon:Show()
      line.icon:SetTexture(e.auto and ICON_AUTO or ICON_BOX)
      line.icon:SetAlpha(e.dim and 0.5 or 1)
      line.fs:SetPoint("TOPLEFT", 18, -2)
      line.fs:SetWidth(cw - 20)
      local label = itemLabel(e.sec, e.j, false)
      line.fs:SetText(e.dim and (GREY .. e.sec.items[e.j][1] .. END) or label)
    end
    local h = math.max(e.head and 20 or 18, line.fs:GetStringHeight() + 6)
    line:SetHeight(h)
    line:ClearAllPoints()
    line:SetPoint("TOPLEFT", mini.child, "TOPLEFT", 0, -y)
    line:Show()
    y = y + h
  end
  for i = #entries + 1, #miniLines do miniLines[i]:Hide() end
  if #entries == 0 then
    mini.doneText:ClearAllPoints()
    mini.doneText:SetPoint("TOPLEFT", mini.child, "TOPLEFT", 2, -2)
    mini.doneText:Show()
    y = 22
  else
    mini.doneText:Hide()
  end
  mini.child:SetHeight(math.max(y, 1))

  -- Alto: automático salvo que lo hayas redimensionado a mano
  local viewH
  if DB.miniSize or mini.sizing then
    viewH = mini:GetHeight() - top - 12
  else
    viewH = math.min(y, MINI_VIEW)
    mini:SetHeight(top + viewH + 12)
  end
  local sb = mini.scroll.ScrollBar
  if type(sb) ~= "table" then sb = _G and _G["ForeverPvPTournamentMiniScrollScrollBar"] end
  if type(sb) == "table" then
    if y > viewH + 1 then sb:Show() else sb:Hide() mini.scroll:SetVerticalScroll(0) end
  end
end

function refresh()
  if not DB then return end
  local done, total, pending, secStats = evaluate()
  refreshFull(done, total, secStats)
  refreshMini(done, total, pending)
end

local function savePos(f, key)
  local point, _, rel, x, y = f:GetPoint()
  DB[key] = {point, rel, x, y}
end
local function loadPos(f, key, default)
  local p = DB[key]
  f:ClearAllPoints()
  if p then f:SetPoint(p[1], UIParent, p[2], p[3], p[4]) else f:SetPoint(unpack(default)) end
end

local function makeDraggable(f, posKey)
  f:SetMovable(true)
  f:EnableMouse(true)
  f:SetClampedToScreen(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() savePos(self, posKey) end)
end

local function setMode(mode)
  if mode ~= "hidden" then DB.lastMode = mode end
  DB.mode = mode
  if mode == "full" then
    mini:Hide(); frame:Show()
  elseif mode == "mini" then
    frame:Hide(); mini:Show()
  else
    frame:Hide(); mini:Hide()
  end
  snapshot()
  refresh()
end
ns.SetMode = setMode

local function createUI()
  ---------------- Lista completa ----------------
  frame = newFrame("ForeverPvPTournamentFrame")
  frame:SetSize(470, 620)
  skin(frame)
  loadPos(frame, "posFull", {"CENTER"})
  makeDraggable(frame, "posFull")
  frame:SetFrameStrata("MEDIUM")

  titleBar(frame, "Forever PvP Tournament", 24)
  local close = smallButton(frame, "x", "Ocultar (vuelve con /tfo o el botón del minimapa)", function() setMode("hidden") end)
  close:SetPoint("TOPRIGHT", -8, -7)
  local minb = smallButton(frame, "–", "Minimizar al tracker", function() setMode("mini") end)
  minb:SetPoint("RIGHT", close, "LEFT", -4, 0)

  frame.progress = progressBar(frame, 446)
  frame.progress:SetPoint("TOPLEFT", 12, -36)

  frame.summary = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  frame.summary:SetPoint("TOPLEFT", 14, -60)
  frame.summary:SetWidth(440)
  frame.summary:SetJustifyH("LEFT")
  frame.summary:SetJustifyV("TOP")
  frame.summary:SetSpacing(2)

  local legend = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  legend:SetPoint("TOPLEFT", 14, -160)
  legend:SetText("|T" .. ICON_DONE .. ":12|t hecho    |T" .. ICON_AUTO .. ":12|t automático    |T" .. ICON_BOX .. ":12|t manual (clic)")

  local sep = frame:CreateTexture(nil, "ARTWORK")
  sep:SetTexture(WHITE8)
  sep:SetVertexColor(0.78, 0.62, 0.28, 0.5)
  sep:SetPoint("TOPLEFT", 10, -176)
  sep:SetPoint("TOPRIGHT", -10, -176)
  sep:SetHeight(1)

  local scroll = CreateFrame("ScrollFrame", "ForeverPvPTournamentScroll", frame, "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", 10, -182)
  scroll:SetPoint("BOTTOMRIGHT", -30, 40)
  scroll:EnableMouseWheel(true)
  scrollChild = CreateFrame("Frame", nil, scroll)
  scrollChild:SetSize(425, 1000)
  scroll:SetScrollChild(scrollChild)

  for _, sec in ipairs(ALL) do
    local hf = CreateFrame("Frame", nil, scrollChild)
    hf:SetSize(420, 24)
    local fs = hf:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    fs:SetPoint("BOTTOMLEFT", 2, 6)
    local count = hf:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    count:SetPoint("BOTTOMRIGHT", -2, 6)
    local ln = hf:CreateTexture(nil, "ARTWORK")
    ln:SetTexture(WHITE8)
    ln:SetVertexColor(0.78, 0.62, 0.28, 0.35)
    ln:SetPoint("BOTTOMLEFT", 0, 2)
    ln:SetPoint("BOTTOMRIGHT", 0, 2)
    ln:SetHeight(1)
    table.insert(rows, {kind = "section", sec = sec, frame = hf, fs = fs, count = count})
    for j = 1, #sec.items do
      local r = CreateFrame("Button", nil, scrollChild)
      r:SetWidth(415)
      r.kind, r.sec, r.j = "item", sec, j
      r.icon = r:CreateTexture(nil, "ARTWORK")
      r.icon:SetSize(14, 14)
      r.icon:SetPoint("TOPLEFT", 2, -3)
      r.fs = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
      r.fs:SetPoint("TOPLEFT", 22, -3)
      r.fs:SetWidth(390)
      r.fs:SetJustifyH("LEFT")
      local hl = r:CreateTexture(nil, "HIGHLIGHT")
      hl:SetTexture(WHITE8)
      hl:SetVertexColor(1, 0.82, 0, 0.07)
      hl:SetAllPoints()
      local key = itemKey(sec, j)
      r:SetScript("OnClick", function() toggleManual(key) refresh() end)
      r:SetScript("OnEnter", rowTooltip)
      r:SetScript("OnLeave", function() GameTooltip:Hide() end)
      table.insert(rows, r)
    end
  end

  local exportBtn = wideButton(frame, "Exportar a la web", 140, function() ns.ShowExport() end)
  exportBtn:SetPoint("BOTTOMLEFT", 12, 10)
  local refreshBtn = wideButton(frame, "Actualizar", 100, function() snapshot() refresh() end)
  refreshBtn:SetPoint("LEFT", exportBtn, "RIGHT", 6, 0)
  local debugBtn = wideButton(frame, "Diagnóstico", 100, function() ns.Debug() end)
  debugBtn:SetPoint("LEFT", refreshBtn, "RIGHT", 6, 0)
  frame:Hide()

  ---------------- Tracker compacto ----------------
  mini = newFrame("ForeverPvPTournamentMini")
  mini:SetSize(DB.miniSize and DB.miniSize[1] or MINI_W, DB.miniSize and DB.miniSize[2] or 160)
  skin(mini, 0.8)
  loadPos(mini, "posMini", {"TOPRIGHT", UIParent, "TOPRIGHT", -80, -220})
  makeDraggable(mini, "posMini")
  mini:SetFrameStrata("LOW")
  mini:SetResizable(true)
  if mini.SetResizeBounds then mini:SetResizeBounds(MIN_W, MIN_H, MAX_W, MAX_H)
  elseif mini.SetMinResize then mini:SetMinResize(MIN_W, MIN_H) if mini.SetMaxResize then mini:SetMaxResize(MAX_W, MAX_H) end end

  titleBar(mini, "Forever PvP", 22)
  local mclose = smallButton(mini, "x", "Ocultar", function() setMode("hidden") end)
  mclose:SetPoint("TOPRIGHT", -7, -6)
  local mexp = smallButton(mini, "+", "Abrir la lista completa", function() setMode("full") end)
  mexp:SetPoint("RIGHT", mclose, "LEFT", -4, 0)

  mini.progress = progressBar(mini, MINI_W - 30)
  mini.progress:SetPoint("TOPLEFT", 10, -32)
  mini.progress:SetPoint("TOPRIGHT", -10, -32)

  mini.stats = mini:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  mini.stats:SetPoint("TOPLEFT", 10, -52)
  mini.stats:SetPoint("TOPRIGHT", -10, -52)
  mini.stats:SetJustifyH("LEFT")

  mini.scroll = CreateFrame("ScrollFrame", "ForeverPvPTournamentMiniScroll", mini, "UIPanelScrollFrameTemplate")
  mini.scroll:SetPoint("TOPLEFT", 8, -70)
  mini.scroll:SetPoint("BOTTOMRIGHT", -26, 12)
  mini.scroll:EnableMouseWheel(true)
  mini.child = CreateFrame("Frame", nil, mini.scroll)
  mini.child:SetSize(MINI_W - 36, 10)
  mini.scroll:SetScrollChild(mini.child)

  mini.doneText = mini.child:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  mini.doneText:SetText(GREEN .. "Todo hecho. ¡Suerte en el torneo!" .. END)
  mini.doneText:Hide()

  -- Esquina para redimensionar (abajo a la derecha)
  local grip = CreateFrame("Button", "ForeverPvPTournamentMiniGrip", mini)
  grip:SetSize(16, 16)
  grip:SetPoint("BOTTOMRIGHT", -3, 3)
  grip:SetFrameLevel((mini:GetFrameLevel() or 1) + 10)
  grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
  grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
  grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
  grip:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  grip:SetScript("OnMouseDown", function(_, button)
    if button == "LeftButton" then mini.sizing = true mini:StartSizing("BOTTOMRIGHT") end
  end)
  grip:SetScript("OnMouseUp", function(_, button)
    if button == "RightButton" then
      DB.miniSize = nil
      mini:SetWidth(MINI_W)
      print(GOLD .. "TFO:" .. END .. " tamaño del tracker en automático.")
    elseif mini.sizing then
      mini:StopMovingOrSizing()
      DB.miniSize = {math.floor(mini:GetWidth() + 0.5), math.floor(mini:GetHeight() + 0.5)}
      savePos(mini, "posMini")
    end
    mini.sizing = false
    refresh()
  end)
  grip:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:AddLine("Arrastra para cambiar el tamaño")
    GameTooltip:AddLine("Clic derecho: volver al tamaño automático", 0.7, 0.7, 0.7)
    GameTooltip:Show()
  end)
  grip:SetScript("OnLeave", function() GameTooltip:Hide() end)

  -- El contenido se recoloca al cambiar el tamaño
  local lastW, lastH = 0, 0
  mini:SetScript("OnSizeChanged", function(self, w, h)
    if math.abs((w or 0) - lastW) < 1 and math.abs((h or 0) - lastH) < 1 then return end
    lastW, lastH = w or 0, h or 0
    if self.sizing or DB.miniSize then refresh() end
  end)
  mini:Hide()
end

------------------------------------------------------------
-- Botón del minimapa
------------------------------------------------------------
local function toggleMain()
  if DB.mode == "full" or DB.mode == "mini" then setMode("hidden")
  else setMode(DB.lastMode or "mini") end
end
ns.Toggle = toggleMain

local function placeMinimapButton(btn)
  local a = math.rad(DB.minimapAngle or 215)
  btn:ClearAllPoints()
  btn:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * 80, math.sin(a) * 80)
end

local function createMinimapButton()
  if not Minimap then return end
  local btn = CreateFrame("Button", "ForeverPvPTournamentMinimapButton", Minimap)
  btn:SetSize(31, 31)
  btn:SetFrameStrata("MEDIUM")
  btn:SetFrameLevel(8)
  btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
  local icon = btn:CreateTexture(nil, "BACKGROUND")
  icon:SetSize(20, 20)
  icon:SetPoint("TOPLEFT", 7, -5)
  icon:SetTexture("Interface\\Icons\\Spell_Nature_BloodLust")
  local border = btn:CreateTexture(nil, "OVERLAY")
  border:SetSize(53, 53)
  border:SetPoint("TOPLEFT")
  border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
  btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  btn:RegisterForDrag("LeftButton")
  btn:SetScript("OnClick", function(_, mouse)
    if mouse == "RightButton" then ns.ShowExport() else toggleMain() end
  end)
  btn:SetScript("OnDragStart", function(self)
    self:SetScript("OnUpdate", function()
      local mx, my = Minimap:GetCenter()
      local cx, cy = GetCursorPosition()
      local scale = Minimap:GetEffectiveScale()
      DB.minimapAngle = math.deg(math.atan2(cy / scale - my, cx / scale - mx))
      placeMinimapButton(self)
    end)
  end)
  btn:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
  btn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine("Forever PvP Tournament")
    GameTooltip:AddLine("Clic: abrir la lista", 1, 1, 1)
    GameTooltip:AddLine("Clic derecho: código para la web", 1, 1, 1)
    GameTooltip:AddLine("Arrastrar: mover el botón", 0.6, 0.6, 0.6)
    GameTooltip:Show()
  end)
  btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
  placeMinimapButton(btn)
end

------------------------------------------------------------
-- Exportar a la web
------------------------------------------------------------
local exportFrame
function ns.ShowExport()
  snapshot()
  local keys = {}
  for _, sec in ipairs(ALL) do
    for j = 1, #sec.items do
      if isDone(sec, j) then table.insert(keys, itemKey(sec, j)) end
    end
  end
  local m = main()
  local ok, total = buildStatus(m)
  local lg = legacyEstimate()
  local code = string.format("TFO1;k=%s;lv=%d;lw=%d;en=%d;lg=%d;tp=%d/%d",
    table.concat(keys, ","), m.level or 0, prof(m, "leatherworking"), prof(m, "engineering"), lg, ok, total)

  if not exportFrame then
    exportFrame = CreateFrame("Frame", "ForeverPvPTournamentExport", UIParent, "BasicFrameTemplateWithInset")
    exportFrame:SetSize(460, 110)
    exportFrame:SetPoint("CENTER", 0, 200)
    exportFrame:SetFrameStrata("DIALOG")
    tinsert(UISpecialFrames, "ForeverPvPTournamentExport")
    local t = exportFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    t:SetPoint("TOP", 0, -6)
    t:SetText("Copia con Ctrl+C y pégalo en la web (Mi guía)")
    local eb = CreateFrame("EditBox", nil, exportFrame, "InputBoxTemplate")
    eb:SetSize(420, 24)
    eb:SetPoint("CENTER", 0, -8)
    eb:SetAutoFocus(true)
    eb:SetScript("OnEscapePressed", function() exportFrame:Hide() end)
    eb:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
    exportFrame.eb = eb
  end
  exportFrame.eb:SetText(code)
  exportFrame:Show()
  exportFrame.eb:SetFocus()
  exportFrame.eb:HighlightText()
end

------------------------------------------------------------
-- Eventos y comandos
------------------------------------------------------------
local pending = false
local function queue()
  if pending then return end
  pending = true
  C_Timer.After(0.5, function()
    pending = false
    snapshot()
    refresh()
  end)
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
for _, e in ipairs({"PLAYER_LEVEL_UP", "SKILL_LINES_CHANGED", "CHARACTER_POINTS_CHANGED", "PLAYER_MONEY",
                    "BAG_UPDATE_DELAYED", "PLAYER_EQUIPMENT_CHANGED", "PLAYER_GUILD_UPDATE",
                    "UPDATE_INVENTORY_DURABILITY", "CHAT_MSG_SKILL", "PLAYER_TALENT_UPDATE", "LEARNED_SPELL_IN_TAB", "SPELLS_CHANGED", "QUEST_TURNED_IN"}) do
  pcall(ev.RegisterEvent, ev, e)
end
ev:SetScript("OnEvent", function(_, event)
  if event == "PLAYER_LOGIN" then
    ForeverPvPTournamentDB = ForeverPvPTournamentDB or {}
    DB = ForeverPvPTournamentDB
    DB.chars = DB.chars or {}
    DB.manual = DB.manual or {}
    DB.routeSeen = DB.routeSeen or {}
    snapshot()
    buildRoute()
    createUI()
    createMinimapButton()
    print(GOLD .. "Forever PvP Tournament" .. END .. " cargado. Botón en el minimapa o " .. WHITE .. "/tfo" .. END .. " para abrir la lista.")
    if not DB.seen then
      DB.seen = true
      DB.mode = "full"
    end
    setMode(DB.mode or "mini")
    if C_Timer.NewTicker then C_Timer.NewTicker(15, function() snapshot() refresh() end) end
  else
    queue()
  end
end)

SLASH_FOREVERPVPTOURNAMENT1 = "/tfo"
SLASH_FOREVERPVPTOURNAMENT2 = "/foreverpvp"
SlashCmdList.FOREVERPVPTOURNAMENT = function(msg)
  msg = string.lower(strtrim(msg or ""))
  if not DB then return end
  if msg == "" then
    toggleMain()
  elseif msg == "debug" or msg == "diagnostico" then
    ns.Debug()
  elseif msg == "mini" then
    setMode("mini")
  elseif msg == "full" or msg == "lista" then
    setMode("full")
  elseif msg == "export" then
    ns.ShowExport()
  elseif msg == "main" then
    snapshot()
    DB.main = charKey()
    print(GOLD .. "TFO:" .. END .. " " .. charKey() .. " es ahora tu main.")
    refresh()
  elseif msg == "alts" then
    for key, c in pairs(DB.chars) do
      print(string.format("%s%s%s %s %s nivel %d", key == DB.main and GOLD or WHITE, key, END, c.race or "?", c.class or "?", c.level or 0))
    end
  elseif msg:match("^legacy") then
    local n = tonumber(msg:match("(%-?%d+)"))
    DB.legacyExtra = n or 0
    print(GOLD .. "TFO:" .. END .. " puntos de Legacy extra (retos de mazmorras, JcJ...): " .. (DB.legacyExtra or 0))
    refresh()
  elseif msg == "reset" then
    print(GOLD .. "TFO:" .. END .. " esto borra las casillas marcadas a mano. Escribe " .. WHITE .. "/tfo reset confirmar" .. END .. " para hacerlo.")
  elseif msg == "reset confirmar" then
    DB.manual = {}
    print(GOLD .. "TFO:" .. END .. " casillas manuales borradas.")
    refresh()
  else
    print(GOLD .. "Forever PvP Tournament" .. END)
    print("/tfo · mostrar u ocultar (vuelve al último modo)")
    print("/tfo mini · tracker compacto · /tfo lista · lista completa")
    print("/tfo debug · qué profesiones y datos detecta el addon")
    print("/tfo export · código para pegar en la web")
    print("/tfo main · marca este personaje como tu main")
    print("/tfo alts · personajes que ha visto el addon")
    print("/tfo legacy N · suma N puntos de Legacy que el addon no puede ver")
    print("/tfo reset · borra las casillas manuales")
  end
end
